# Componentes de terceiros embutidos (sem alteração)

- **Exposure 1.9.24** — autor: mortuusars — licença declarada no mods.toml: MIT.
- **Exposure Polaroid 1.1.4** — autor: mortuusars — licença declarada no mods.toml: MIT.
- MixinExtras 0.4.1 (embutido via JarJar pelo Exposure).

Os arquivos originais estão em `libs/originais/` e são incluídos no JAR final exatamente como foram recebidos.
A licença MIT exige manter o aviso de copyright e o texto da licença. Os JARs recebidos NÃO trazem o arquivo
LICENSE: copie o texto oficial (com a linha de copyright) dos repositórios dos autores para este arquivo
antes de redistribuir o JAR.

**Exposure Detective 1.1.0 (All Rights Reserved) NÃO está incluído em nenhum artefato.**
