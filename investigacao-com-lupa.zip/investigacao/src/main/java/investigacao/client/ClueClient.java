package investigacao.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import investigacao.Investigacao;
import investigacao.clue.ClueData.Link;
import investigacao.clue.ClueData.Pin;
import investigacao.items.ClueLineItem;
import investigacao.networking.BreakClueMessage;
import investigacao.networking.ModNetwork;
import investigacao.networking.PlaceClueMessage;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/**
 * Linha Vermelha: cada clique prega um quadradinho (1º vermelho, depois azuis) ligado ao anterior por uma
 * linha reta (sem física). Enquanto a corrente está aberta, um quadradinho que muda de cor mostra onde o
 * próximo vai ficar, com a linha esticada até ele. Soco num pino/linha remove.
 */
public final class ClueClient {
    private static final ResourceLocation TEX = new ResourceLocation(Investigacao.MOD_ID, "textures/string.png");
    private static final double H = 0.045;            // meia-aresta do pino
    private static final double LINE_HALF = 0.012;
    private static final int LINE_RGB = 0xC81414;

    private static List<Pin> pins = new ArrayList<>();
    private static List<Link> links = new ArrayList<>();
    private static Vec3 last; // último pino da corrente aberta

    private ClueClient() {}

    public static void receive(List<Pin> p, List<Link> l) { pins = new ArrayList<>(p); links = new ArrayList<>(l); }

    private static boolean holding(Player p) {
        if (p == null) return false;
        for (ItemStack s : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) if (s.getItem() instanceof ClueLineItem) return true;
        return false;
    }

    private static void handleUse(UseOnContext c) {
        Vec3 n = Vec3.atLowerCornerOf(c.getClickedFace().getNormal());
        Vec3 pos = c.getClickLocation().add(n.scale(H));
        ModNetwork.sendToServer(new PlaceClueMessage(pos, n, last));
        last = pos;
    }

    // ------------------------------------------------------------ soco remove
    private static void onAttack(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (!e.isAttack() || mc.player == null || (pins.isEmpty() && links.isEmpty())) return;
        Vec3 o = mc.player.getEyePosition(), d = mc.player.getViewVector(1.0f).normalize();
        double max = 5.0;
        HitResult hr = mc.hitResult;
        if (hr != null && hr.getType() == HitResult.Type.BLOCK) max = Math.min(max, o.distanceTo(hr.getLocation()) + 0.1);
        double bestT = Double.MAX_VALUE;
        BreakClueMessage msg = null;
        for (Pin p : pins) {
            double[] r = TapeClient.raySegment(o, d, max, p.pos(), p.pos());
            if (r[0] <= 0.1 && r[1] < bestT) { bestT = r[1]; msg = new BreakClueMessage(p.pos(), p.pos(), true); }
        }
        for (Link l : links) {
            double[] r = TapeClient.raySegment(o, d, max, l.a(), l.b());
            if (r[0] <= 0.1 && r[1] < bestT - 0.05) { bestT = r[1]; msg = new BreakClueMessage(l.a(), l.b(), false); }
        }
        if (msg == null) return;
        ModNetwork.sendToServer(msg);
        if (msg.pin() && last != null && last.distanceToSqr(msg.a()) < 1.0E-6) last = null;
        e.setCanceled(true);
        e.setSwingHint(true);
    }

    // ------------------------------------------------------------ desenho
    private static void render(RenderLevelStageEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack.Pose pose = e.getPoseStack().last();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        RenderType rt = RenderType.entityCutoutNoCull(TEX);
        VertexConsumer vc = bs.getBuffer(rt);
        for (Link l : links) {
            if (cam.distanceToSqr(l.a()) > 128 * 128) continue;
            line(vc, pose, mc, cam, l.a(), l.b());
        }
        for (Pin p : pins) {
            if (cam.distanceToSqr(p.pos()) > 96 * 96) continue;
            cube(vc, pose, mc, cam, p.pos(), p.color());
        }
        if (holding(mc.player)) {
            Vec3 target = null;
            HitResult hr = mc.hitResult;
            if (hr instanceof BlockHitResult b && hr.getType() == HitResult.Type.BLOCK) {
                target = b.getLocation().add(Vec3.atLowerCornerOf(b.getDirection().getNormal()).scale(H));
                float hue = (System.currentTimeMillis() % 2400L) / 2400f;
                cube(vc, pose, mc, cam, target, Mth.hsvToRgb(hue, 0.85f, 0.95f));
            } else if (last != null) {
                target = mc.player.getEyePosition().add(mc.player.getViewVector(1.0f).scale(3.0));
            }
            if (last != null && target != null) line(vc, pose, mc, cam, last, target);
        }
        bs.endBatch(rt);
    }

    private static int light(Minecraft mc, Vec3 p) {
        BlockPos bp = BlockPos.containing(p);
        return LightTexture.pack(mc.level.getBrightness(LightLayer.BLOCK, bp), mc.level.getBrightness(LightLayer.SKY, bp));
    }

    private static void line(VertexConsumer vc, PoseStack.Pose pose, Minecraft mc, Vec3 cam, Vec3 wa, Vec3 wb) {
        Vec3 a = wa.subtract(cam), b = wb.subtract(cam);
        Vec3 dir = b.subtract(a);
        if (dir.lengthSqr() < 1.0E-8) return;
        dir = dir.normalize();
        Vec3 mid = a.add(b).scale(0.5);
        Vec3 side = dir.cross(mid.lengthSqr() > 1.0E-6 ? mid.normalize() : new Vec3(0, 1, 0));
        if (side.lengthSqr() < 1.0E-8) side = dir.cross(new Vec3(0, 1, 0));
        side = side.normalize().scale(LINE_HALF);
        Vec3 n = side.cross(dir).normalize();
        int l = light(mc, wa.add(wb).scale(0.5)), r = (LINE_RGB >> 16) & 255, g = (LINE_RGB >> 8) & 255, bl = LINE_RGB & 255;
        v(vc, pose, a.add(side), 0, 0, l, n, r, g, bl);
        v(vc, pose, a.subtract(side), 0, 1, l, n, r, g, bl);
        v(vc, pose, b.subtract(side), 1, 1, l, n, r, g, bl);
        v(vc, pose, b.add(side), 1, 0, l, n, r, g, bl);
    }

    private static void cube(VertexConsumer vc, PoseStack.Pose pose, Minecraft mc, Vec3 cam, Vec3 world, int rgb) {
        Vec3 c = world.subtract(cam);
        int l = light(mc, world);
        for (int axis = 0; axis < 3; axis++) {
            for (int sign = -1; sign <= 1; sign += 2) {
                double[] n = new double[3]; n[axis] = sign;
                int t1 = (axis + 1) % 3, t2 = (axis + 2) % 3;
                float shade = axis == 1 ? (sign > 0 ? 1.0f : 0.55f) : (axis == 0 ? 0.8f : 0.7f);
                int r = (int) (((rgb >> 16) & 255) * shade), g = (int) (((rgb >> 8) & 255) * shade), b = (int) ((rgb & 255) * shade);
                double[][] uv = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
                for (double[] q : uv) {
                    double[] p = {c.x, c.y, c.z};
                    p[axis] += n[axis] * H; p[t1] += q[0] * H; p[t2] += q[1] * H;
                    v(vc, pose, new Vec3(p[0], p[1], p[2]), (float) (q[0] + 1) / 2f, (float) (q[1] + 1) / 2f, l,
                            new Vec3(n[0], n[1], n[2]), r, g, b);
                }
            }
        }
    }

    private static void v(VertexConsumer vc, PoseStack.Pose pose, Vec3 pos, float u, float vv, int light, Vec3 n, int r, int g, int b) {
        vc.vertex(pose.pose(), (float) pos.x, (float) pos.y, (float) pos.z).color(r, g, b, 255).uv(u, vv)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
                .normal(pose.normal(), (float) n.x, (float) n.y, (float) n.z).endVertex();
    }

    // ------------------------------------------------------------ eventos
    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void setup(FMLClientSetupEvent e) {
            ClueLineItem.onUseBlock = ClueClient::handleUse;
            ClueLineItem.onEnd = () -> last = null;
        }
    }

    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void tick(TickEvent.ClientTickEvent e) {
            if (e.phase == TickEvent.Phase.END && last != null && !holding(Minecraft.getInstance().player)) last = null;
        }

        @SubscribeEvent
        public static void attack(InputEvent.InteractionKeyMappingTriggered e) { onAttack(e); }

        @SubscribeEvent
        public static void renderStage(RenderLevelStageEvent e) {
            if (e.getStage() == RenderLevelStageEvent.Stage.AFTER_ENTITIES) render(e);
        }

        @SubscribeEvent
        public static void logout(ClientPlayerNetworkEvent.LoggingOut e) { pins = new ArrayList<>(); links = new ArrayList<>(); last = null; }
    }
}
