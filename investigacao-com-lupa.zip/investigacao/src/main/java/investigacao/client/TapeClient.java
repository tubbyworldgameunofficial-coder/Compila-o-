package investigacao.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import investigacao.Investigacao;
import investigacao.items.TapeItem;
import investigacao.networking.ModNetwork;
import investigacao.networking.PlaceTapeMessage;
import investigacao.tape.RopeSim;
import investigacao.tape.Tape;
import investigacao.tape.TapeService;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

/** Lado cliente da faixa/fios: uso do item, física (tick) e desenho. */
public final class TapeClient {
    private static final ResourceLocation TAPE_TEX = new ResourceLocation(Investigacao.MOD_ID, "textures/warning_tape.png");
    private static final ResourceLocation STRING_TEX = new ResourceLocation(Investigacao.MOD_ID, "textures/string.png");
    /** Deslocamento em relação ao bloco clicado (evita z-fighting/colisão). */
    private static final double OFFSET = 0.05;
    private static final double TAPE_HALF_WIDTH = 0.12;
    private static final double STRING_HALF_WIDTH = 0.02;
    /** A textura da faixa tem 28 repetições de ~0.885 blocos de comprimento. */
    /** A textura tem 1 texto (proporção 4:1): um texto a cada 4x a largura da faixa, repetindo ao longo. */
    private static final double TEX_LENGTH = 4 * 2 * TAPE_HALF_WIDTH;

    private record Entry(Tape tape, RopeSim sim) {}

    private static final List<Entry> TAPES = new ArrayList<>();
    private static Vec3 start;
    private static boolean startFlat;
    private static int startColor = -1;
    private static RopeSim preview;

    private TapeClient() {}

    public static void receive(List<Tape> tapes) {
        TAPES.clear();
        for (Tape t : tapes) TAPES.add(new Entry(t, new RopeSim(t.a(), t.b())));
    }

    // ---------------------------------------------------------------- uso do item

    private static Vec3 offsetPoint(Vec3 hit, Direction side) {
        return hit.add(Vec3.atLowerCornerOf(side.getNormal()).scale(OFFSET));
    }

    private static void handleUse(UseOnContext ctx, TapeItem item) {
        Vec3 p = offsetPoint(ctx.getClickLocation(), ctx.getClickedFace());
        boolean flat = ctx.getClickedFace().getAxis() == Direction.Axis.Y;
        if (start == null || startColor != item.color()) {
            start = p;
            startFlat = flat;
            startColor = item.color();
            preview = new RopeSim(p, p.add(0, 0, 0.01));
            return;
        }
        if (start.distanceTo(p) > TapeService.MAX_LEN) {
            msg("Longe demais (máx. " + (int) TapeService.MAX_LEN + " blocos).");
            return;
        }
        ModNetwork.sendToServer(new PlaceTapeMessage(start, p, startFlat && flat, startColor));
        cancel();
    }

    private static void cancel() {
        start = null;
        preview = null;
    }

    private static void msg(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal(s), true);
    }

    // ---------------------------------------------------------------- soco quebra a fita

    private static final double BREAK_REACH = 5.0, BREAK_RADIUS = 0.22;

    /** Distância mínima entre o raio (o, d unitário, 0..len) e o segmento (p, q). Retorna {dist, tNoRaio}. */
    static double[] raySegment(Vec3 o, Vec3 d, double len, Vec3 p, Vec3 q) {
        Vec3 e = q.subtract(p), w0 = o.subtract(p);
        double a = d.dot(d), b = d.dot(e), c = e.dot(e), dd = d.dot(w0), ee = e.dot(w0);
        if (c < 1.0E-12) { double s0 = Math.max(0, Math.min(len, -dd)); return new double[]{o.add(d.scale(s0)).distanceTo(p), s0}; }
        double den = a * c - b * b, sc, tc;
        if (den < 1.0E-9) { sc = 0; tc = c > 1.0E-12 ? ee / c : 0; }
        else { sc = (b * ee - c * dd) / den; tc = (a * ee - b * dd) / den; }
        sc = Math.max(0, Math.min(len, sc));
        tc = c > 1.0E-12 ? Math.max(0, Math.min(1, (ee + b * sc) / c)) : 0;
        Vec3 onRay = o.add(d.scale(sc)), onSeg = p.add(e.scale(tc));
        return new double[]{onRay.distanceTo(onSeg), sc};
    }

    /** Acha a fita que o jogador está socando (antes de qualquer bloco). */
    private static Tape pickTape(Minecraft mc) {
        Vec3 o = mc.player.getEyePosition();
        Vec3 d = mc.player.getViewVector(1.0f).normalize();
        double max = BREAK_REACH;
        HitResult hr = mc.hitResult;
        if (hr != null && hr.getType() == HitResult.Type.BLOCK) max = Math.min(max, o.distanceTo(hr.getLocation()) + 0.1);
        Tape best = null;
        double bestT = Double.MAX_VALUE;
        for (Entry en : TAPES) {
            RopeSim s = en.sim();
            for (int i = 0; i < RopeSim.POINTS - 1; i++) {
                double[] r = raySegment(o, d, max, new Vec3(s.x[i], s.y[i], s.z[i]), new Vec3(s.x[i + 1], s.y[i + 1], s.z[i + 1]));
                double rad = en.tape().isString() ? 0.12 : BREAK_RADIUS;
                if (r[0] <= rad && r[1] < bestT) { bestT = r[1]; best = en.tape(); }
            }
        }
        return best;
    }

    private static void onAttack(InputEvent.InteractionKeyMappingTriggered e) {
        Minecraft mc = Minecraft.getInstance();
        if (!e.isAttack() || mc.player == null || mc.level == null || TAPES.isEmpty()) return;
        Tape t = pickTape(mc);
        if (t == null) return;
        ModNetwork.sendToServer(new investigacao.networking.BreakTapeMessage(t.a(), t.b()));
        e.setCanceled(true);       // não quebra o bloco atrás
        e.setSwingHint(true);      // mas o braço balança
    }

    // ---------------------------------------------------------------- tick (física)

    private static void tick(Minecraft mc) {
        if (mc.level == null || mc.player == null) return;
        Vec3 cam = mc.player.getEyePosition();
        for (Entry e : TAPES) {
            if (cam.distanceToSqr(e.tape().a()) > 96 * 96) continue;
            e.sim().update(mc.level, e.tape().a(), e.tape().b());
        }
        if (start == null) return;
        if (!TapeService.holds(mc.player, startColor)) { cancel(); return; }
        Vec3 end;
        HitResult hr = mc.hitResult;
        if (hr != null && hr.getType() == HitResult.Type.BLOCK) {
            BlockHitResult b = (BlockHitResult) hr;
            end = offsetPoint(b.getLocation(), b.getDirection());
        } else {
            end = mc.player.getEyePosition().add(mc.player.getViewVector(1.0f).scale(5.0));
        }
        Vec3 d = end.subtract(start);
        if (d.length() > TapeService.MAX_LEN) end = start.add(d.normalize().scale(TapeService.MAX_LEN));
        preview.update(mc.level, start, end);
    }

    // ---------------------------------------------------------------- desenho

    private static void render(RenderLevelStageEvent e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack.Pose pose = e.getPoseStack().last();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();

        // passe 1: faixas de isolamento (textura listrada)
        RenderType tapeType = RenderType.entityCutoutNoCull(TAPE_TEX);
        VertexConsumer vc = bs.getBuffer(tapeType);
        for (Entry en : TAPES) {
            if (en.tape().isString() || cam.distanceToSqr(en.tape().a()) > 128 * 128) continue;
            drawRope(vc, pose, mc.level, cam, en.sim(), en.tape().flat(), TAPE_HALF_WIDTH, true, -1);
        }
        if (start != null && preview != null && startColor < 0)
            drawRope(vc, pose, mc.level, cam, preview, startFlat, TAPE_HALF_WIDTH, true, -1);
        bs.endBatch(tapeType);

        // passe 2: fios coloridos (textura branca tingida por vértice)
        RenderType strType = RenderType.entityCutoutNoCull(STRING_TEX);
        vc = bs.getBuffer(strType);
        for (Entry en : TAPES) {
            if (!en.tape().isString() || cam.distanceToSqr(en.tape().a()) > 128 * 128) continue;
            drawRope(vc, pose, mc.level, cam, en.sim(), en.tape().flat(), STRING_HALF_WIDTH, false, en.tape().color());
        }
        if (start != null && preview != null && startColor >= 0)
            drawRope(vc, pose, mc.level, cam, preview, startFlat, STRING_HALF_WIDTH, false, startColor);
        bs.endBatch(strType);
    }

    private static void drawRope(VertexConsumer vc, PoseStack.Pose pose, Level world, Vec3 cam, RopeSim s,
                                 boolean flat, double halfWidth, boolean stretchTex, int rgb) {
        int cr = rgb < 0 ? 255 : (rgb >> 16) & 255, cg = rgb < 0 ? 255 : (rgb >> 8) & 255, cb = rgb < 0 ? 255 : rgb & 255;
        Vec3[] p = new Vec3[RopeSim.POINTS];
        double[] cum = new double[RopeSim.POINTS];
        for (int i = 0; i < RopeSim.POINTS; i++) {
            p[i] = new Vec3(s.x[i] - cam.x, s.y[i] - cam.y, s.z[i] - cam.z);
            if (i > 0) cum[i] = cum[i - 1] + p[i].distanceTo(p[i - 1]);
        }
        for (int i = 0; i < RopeSim.POINTS - 1; i++) {
            Vec3 a = p[i], b = p[i + 1];
            Vec3 dir = b.subtract(a);
            if (dir.lengthSqr() < 1.0E-10) continue;
            dir = dir.normalize();
            Vec3 mid = a.add(b).scale(0.5);
            Vec3 nrm = flat ? new Vec3(0, 1, 0) : (mid.lengthSqr() > 1.0E-6 ? mid.normalize() : new Vec3(0, 0, 1));
            Vec3 side = dir.cross(nrm);
            if (side.lengthSqr() < 1.0E-6) side = dir.cross(flat ? new Vec3(1, 0, 0) : new Vec3(0, 1, 0));
            side = side.normalize().scale(halfWidth);
            Vec3 n = side.cross(dir).normalize();
            BlockPos bp = BlockPos.containing(mid.x + cam.x, mid.y + cam.y, mid.z + cam.z);
            int light = LightTexture.pack(world.getBrightness(LightLayer.BLOCK, bp), world.getBrightness(LightLayer.SKY, bp));
            float u0 = stretchTex ? (float) (cum[i] / TEX_LENGTH) : 0f;
            float u1 = stretchTex ? (float) (cum[i + 1] / TEX_LENGTH) : 1f;
            Vec3 a1 = a.add(side), a2 = a.subtract(side), b2 = b.subtract(side), b1 = b.add(side);
            // frente
            vert(vc, pose, a1, u0, 0f, light, n, cr, cg, cb);
            vert(vc, pose, a2, u0, 1f, light, n, cr, cg, cb);
            vert(vc, pose, b2, u1, 1f, light, n, cr, cg, cb);
            vert(vc, pose, b1, u1, 0f, light, n, cr, cg, cb);
            // verso
            Vec3 m = n.scale(-1);
            vert(vc, pose, b1, u1, 0f, light, m, cr, cg, cb);
            vert(vc, pose, b2, u1, 1f, light, m, cr, cg, cb);
            vert(vc, pose, a2, u0, 1f, light, m, cr, cg, cb);
            vert(vc, pose, a1, u0, 0f, light, m, cr, cg, cb);
        }
    }

    private static void vert(VertexConsumer vc, PoseStack.Pose pose, Vec3 pos, float u, float v, int light, Vec3 n,
                             int r, int g, int b) {
        vc.vertex(pose.pose(), (float) pos.x, (float) pos.y, (float) pos.z)
                .color(r, g, b, 255)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), (float) n.x, (float) n.y, (float) n.z)
                .endVertex();
    }

    // ---------------------------------------------------------------- eventos de cliente

    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent e) {
            TapeItem.onUseBlock = TapeClient::handleUse;
            TapeItem.onCancel = TapeClient::cancel;
        }
    }

    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void onTick(TickEvent.ClientTickEvent e) {
            if (e.phase == TickEvent.Phase.END) tick(Minecraft.getInstance());
        }

        @SubscribeEvent
        public static void onAttackKey(InputEvent.InteractionKeyMappingTriggered e) { onAttack(e); }

        @SubscribeEvent
        public static void onRender(RenderLevelStageEvent e) {
            if (e.getStage() == RenderLevelStageEvent.Stage.AFTER_ENTITIES) render(e);
        }

        @SubscribeEvent
        public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
            TAPES.clear();
            cancel();
        }
    }
}
