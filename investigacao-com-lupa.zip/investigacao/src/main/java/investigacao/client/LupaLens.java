package investigacao.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.pipeline.RenderTarget;
import com.mojang.blaze3d.pipeline.TextureTarget;
import com.mojang.blaze3d.systems.RenderSystem;
import investigacao.Investigacao;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.AbstractTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

/**
 * Textura da lente: a cada frame copia (na GPU) um quadrado central da tela, já renderizada,
 * para um framebuffer pequeno. Esse framebuffer vira a textura do vidro da lupa.
 */
public final class LupaLens {
    public static final ResourceLocation LOCATION = new ResourceLocation(Investigacao.MOD_ID, "dynamic/lupa_lente");
    /** Quantas vezes a imagem do centro é ampliada. */
    public static float ZOOM = 3.0f;
    private static final int SIZE = 256;
    private static TextureTarget target;
    private static boolean ready, broken;

    private LupaLens() {}

    public static boolean ready() { return ready && !broken; }

    public static void capture(Minecraft mc) {
        if (broken) return;
        try {
            if (target == null) {
                target = new TextureTarget(SIZE, SIZE, false, Minecraft.ON_OSX);
                final TextureTarget t = target;
                mc.getTextureManager().register(LOCATION, new AbstractTexture() {
                    @Override public void load(ResourceManager rm) throws IOException { }
                    @Override public int getId() { return t.getColorTextureId(); }
                });
            }
            RenderTarget main = mc.getMainRenderTarget();
            int w = main.viewWidth, h = main.viewHeight;
            int s = Math.max(8, Math.round(h / ZOOM));
            int x0 = (w - s) / 2, y0 = (h - s) / 2;
            GlStateManager._glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.frameBufferId);
            GlStateManager._glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, target.frameBufferId);
            GL30.glBlitFramebuffer(x0, y0, x0 + s, y0 + s, 0, 0, SIZE, SIZE, GL11.GL_COLOR_BUFFER_BIT, GL11.GL_LINEAR);
            // alfa = 1 em tudo (o framebuffer principal pode ter alfa 0 e o vidro sumiria)
            GlStateManager._glBindFramebuffer(GL30.GL_FRAMEBUFFER, target.frameBufferId);
            RenderSystem.colorMask(false, false, false, true);
            RenderSystem.clearColor(0f, 0f, 0f, 1f);
            RenderSystem.clear(GL11.GL_COLOR_BUFFER_BIT, Minecraft.ON_OSX);
            RenderSystem.colorMask(true, true, true, true);
            main.bindWrite(true);
            ready = true;
        } catch (Throwable t) { // GPU/launcher sem glBlitFramebuffer: lente fica como vidro comum
            broken = true;
            Investigacao.LOG.error("Lente da lupa desativada (falha na captura)", t);
            try { mc.getMainRenderTarget().bindWrite(true); } catch (Throwable ignored) {}
        }
    }
}
