package investigacao.client;

import investigacao.Investigacao;
import investigacao.items.LupaItem;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ModelEvent;
import net.minecraftforge.client.event.RenderHandEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Eventos da Lupa: registra os modelos 3D e captura a imagem da lente antes de desenhar a mão. */
public final class LupaClient {
    private LupaClient() {}

    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void models(ModelEvent.RegisterAdditional e) {
            e.register(LupaRenderer.FULL);
            e.register(LupaRenderer.BODY);
        }
    }

    @Mod.EventBusSubscriber(modid = Investigacao.MOD_ID, value = Dist.CLIENT)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void hand(RenderHandEvent e) {
            if (e.getItemStack().getItem() instanceof LupaItem) LupaLens.capture(Minecraft.getInstance());
        }
    }
}
