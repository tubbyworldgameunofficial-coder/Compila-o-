package investigacao.networking;

import investigacao.clue.ClueService;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: soco num pino (pin=true, usa a) ou numa linha (a-b). */
public record BreakClueMessage(Vec3 a, Vec3 b, boolean pin) {
    public static void encode(BreakClueMessage m, FriendlyByteBuf f) {
        f.writeDouble(m.a.x); f.writeDouble(m.a.y); f.writeDouble(m.a.z);
        f.writeDouble(m.b.x); f.writeDouble(m.b.y); f.writeDouble(m.b.z);
        f.writeBoolean(m.pin);
    }

    public static BreakClueMessage decode(FriendlyByteBuf f) {
        return new BreakClueMessage(new Vec3(f.readDouble(), f.readDouble(), f.readDouble()),
                new Vec3(f.readDouble(), f.readDouble(), f.readDouble()), f.readBoolean());
    }

    public static void handle(BreakClueMessage m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> { ServerPlayer p = ctx.getSender(); if (p != null) ClueService.remove(p, m.a, m.b, m.pin); });
        ctx.setPacketHandled(true);
    }
}
