package investigacao.networking;

import investigacao.clue.ClueService;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkEvent;

/** Cliente -> servidor: pregar um pino em pos (ligando ao pino anterior, se houver). */
public record PlaceClueMessage(Vec3 pos, Vec3 normal, Vec3 prev) {
    public static void encode(PlaceClueMessage m, FriendlyByteBuf b) {
        b.writeDouble(m.pos.x); b.writeDouble(m.pos.y); b.writeDouble(m.pos.z);
        b.writeDouble(m.normal.x); b.writeDouble(m.normal.y); b.writeDouble(m.normal.z);
        b.writeBoolean(m.prev != null);
        if (m.prev != null) { b.writeDouble(m.prev.x); b.writeDouble(m.prev.y); b.writeDouble(m.prev.z); }
    }

    public static PlaceClueMessage decode(FriendlyByteBuf b) {
        Vec3 pos = new Vec3(b.readDouble(), b.readDouble(), b.readDouble());
        Vec3 n = new Vec3(b.readDouble(), b.readDouble(), b.readDouble());
        Vec3 prev = b.readBoolean() ? new Vec3(b.readDouble(), b.readDouble(), b.readDouble()) : null;
        return new PlaceClueMessage(pos, n, prev);
    }

    public static void handle(PlaceClueMessage m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> { ServerPlayer p = ctx.getSender(); if (p != null) ClueService.place(p, m.pos, m.normal, m.prev); });
        ctx.setPacketHandled(true);
    }
}
