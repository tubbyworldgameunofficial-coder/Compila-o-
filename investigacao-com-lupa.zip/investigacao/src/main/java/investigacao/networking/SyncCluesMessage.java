package investigacao.networking;

import investigacao.client.ClueClient;
import investigacao.clue.ClueData.Link;
import investigacao.clue.ClueData.Pin;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Servidor -> cliente: todos os pinos e linhas da dimensão. */
public record SyncCluesMessage(List<Pin> pins, List<Link> links) {
    private static void wv(FriendlyByteBuf b, Vec3 v) { b.writeDouble(v.x); b.writeDouble(v.y); b.writeDouble(v.z); }
    private static Vec3 rv(FriendlyByteBuf b) { return new Vec3(b.readDouble(), b.readDouble(), b.readDouble()); }

    public static void encode(SyncCluesMessage m, FriendlyByteBuf b) {
        b.writeVarInt(m.pins.size());
        for (Pin p : m.pins) { wv(b, p.pos()); wv(b, p.normal()); b.writeBoolean(p.start()); }
        b.writeVarInt(m.links.size());
        for (Link l : m.links) { wv(b, l.a()); wv(b, l.b()); }
    }

    public static SyncCluesMessage decode(FriendlyByteBuf b) {
        int n = b.readVarInt();
        List<Pin> pins = new ArrayList<>(n);
        for (int i = 0; i < n; i++) pins.add(new Pin(rv(b), rv(b), b.readBoolean()));
        int k = b.readVarInt();
        List<Link> links = new ArrayList<>(k);
        for (int i = 0; i < k; i++) links.add(new Link(rv(b), rv(b)));
        return new SyncCluesMessage(pins, links);
    }

    public static void handle(SyncCluesMessage m, Supplier<NetworkEvent.Context> sup) {
        NetworkEvent.Context ctx = sup.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClueClient.receive(m.pins, m.links)));
        ctx.setPacketHandled(true);
    }
}
