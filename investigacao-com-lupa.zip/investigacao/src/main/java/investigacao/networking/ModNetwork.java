package investigacao.networking;

import investigacao.Investigacao;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Investigacao.MOD_ID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNetwork() {}

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, PlaceTapeMessage.class,
                PlaceTapeMessage::encode, PlaceTapeMessage::decode, PlaceTapeMessage::handle);
        CHANNEL.registerMessage(id++, BreakTapeMessage.class,
                BreakTapeMessage::encode, BreakTapeMessage::decode, BreakTapeMessage::handle);
        CHANNEL.registerMessage(id++, PlaceClueMessage.class,
                PlaceClueMessage::encode, PlaceClueMessage::decode, PlaceClueMessage::handle);
        CHANNEL.registerMessage(id++, BreakClueMessage.class,
                BreakClueMessage::encode, BreakClueMessage::decode, BreakClueMessage::handle);
        CHANNEL.registerMessage(id++, SyncCluesMessage.class,
                SyncCluesMessage::encode, SyncCluesMessage::decode, SyncCluesMessage::handle);
        CHANNEL.registerMessage(id++, SyncTapesMessage.class,
                SyncTapesMessage::encode, SyncTapesMessage::decode, SyncTapesMessage::handle);
    }

    public static void sendToServer(Object msg) { CHANNEL.sendToServer(msg); }

    public static void sendTo(ServerPlayer p, Object msg) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), msg);
    }
}
