package investigacao.registry;

import investigacao.Investigacao;
import investigacao.block.BoardBlock;
import investigacao.block.BoardBlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, Investigacao.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Investigacao.MOD_ID);

    public static final RegistryObject<Block> BOARD = BLOCKS.register("investigation_board",
            () -> new BoardBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.WOOD).strength(1.0F).sound(SoundType.WOOD).noOcclusion()));

    public static final RegistryObject<BlockEntityType<BoardBlockEntity>> BOARD_BE = BLOCK_ENTITIES.register(
            "investigation_board",
            () -> BlockEntityType.Builder.of(BoardBlockEntity::new, BOARD.get()).build(null));

    private ModBlocks() {}
}
