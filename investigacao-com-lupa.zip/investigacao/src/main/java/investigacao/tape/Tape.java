package investigacao.tape;

import net.minecraft.world.phys.Vec3;

/**
 * Fita/fio fixado no mundo entre A e B.
 * flat = deitado (os dois cliques foram em face horizontal).
 * color = -1 para a Faixa de Isolamento (textura listrada); caso contrário, cor RGB (0xRRGGBB) de um fio de carretel.
 */
public record Tape(Vec3 a, Vec3 b, boolean flat, int color) {
    public boolean isString() { return color >= 0; }
}
