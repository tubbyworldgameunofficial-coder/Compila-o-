package investigacao.block;

import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Quadro de investigação. Clique direito com uma fotografia do Exposure (gerada pela Câmera Instantânea do Polaroid
 * ou pela câmera comum) para fixá-la; agachado com a mão vazia, retira a última. Os fios coloridos (carretéis)
 * podem ser esticados entre quaisquer blocos, inclusive no quadro.
 * As fotos são reconhecidas pelo ID do item (sem dependência de código do Exposure).
 */
public class BoardBlock extends HorizontalDirectionalBlock implements EntityBlock {
    /** IDs dos itens de foto do Exposure. */
    public static final Set<String> PHOTO_ITEMS = Set.of(
            "exposure:photograph", "exposure:aged_photograph", "exposure:stacked_photographs");

    private static final VoxelShape NORTH_SHAPE = Block.box(0, 0, 14, 16, 16, 16);
    private static final VoxelShape SOUTH_SHAPE = Block.box(0, 0, 0, 16, 16, 2);
    private static final VoxelShape WEST_SHAPE = Block.box(14, 0, 0, 16, 16, 16);
    private static final VoxelShape EAST_SHAPE = Block.box(0, 0, 0, 2, 16, 16);

    public BoardBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    public static boolean isPhoto(ItemStack stack) {
        ResourceLocation key = ForgeRegistries.ITEMS.getKey(stack.getItem());
        return key != null && PHOTO_ITEMS.contains(key.toString());
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        return defaultBlockState().setValue(FACING, ctx.getHorizontalDirection().getOpposite());
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return switch (state.getValue(FACING)) {
            case SOUTH -> SOUTH_SHAPE;
            case WEST -> WEST_SHAPE;
            case EAST -> EAST_SHAPE;
            default -> NORTH_SHAPE;
        };
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BoardBlockEntity(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean photo = isPhoto(held);
        boolean takeOut = held.isEmpty() && player.isShiftKeyDown();
        if (!photo && !takeOut) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(level.getBlockEntity(pos) instanceof BoardBlockEntity be)) return InteractionResult.PASS;

        if (photo) {
            ItemStack one = held.copy();
            one.setCount(1);
            if (!be.addPhoto(one)) {
                player.displayClientMessage(Component.literal("O quadro está cheio."), true);
                return InteractionResult.CONSUME;
            }
            if (!player.getAbilities().instabuild) held.shrink(1);
        } else {
            ItemStack out = be.removeLast();
            if (out.isEmpty()) return InteractionResult.CONSUME;
            if (!player.getInventory().add(out)) player.drop(out, false);
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof BoardBlockEntity be) {
            be.dropAll(level, pos);
        }
        super.onRemove(state, level, pos, newState, moving);
    }
}
