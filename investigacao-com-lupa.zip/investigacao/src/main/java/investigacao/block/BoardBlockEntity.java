package investigacao.block;

import investigacao.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.world.Containers;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Guarda até 9 fotografias (itens do Exposure) fixadas no quadro, numa grade 3x3. */
public class BoardBlockEntity extends BlockEntity {
    public static final int SLOTS = 9;
    private final NonNullList<ItemStack> photos = NonNullList.withSize(SLOTS, ItemStack.EMPTY);

    public BoardBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlocks.BOARD_BE.get(), pos, state);
    }

    public NonNullList<ItemStack> photos() { return photos; }

    public boolean addPhoto(ItemStack stack) {
        for (int i = 0; i < SLOTS; i++) {
            if (photos.get(i).isEmpty()) {
                photos.set(i, stack);
                sync();
                return true;
            }
        }
        return false;
    }

    public ItemStack removeLast() {
        for (int i = SLOTS - 1; i >= 0; i--) {
            if (!photos.get(i).isEmpty()) {
                ItemStack s = photos.get(i);
                photos.set(i, ItemStack.EMPTY);
                sync();
                return s;
            }
        }
        return ItemStack.EMPTY;
    }

    public void dropAll(Level level, BlockPos pos) {
        Containers.dropContents(level, pos, photos);
    }

    private void sync() {
        setChanged();
        if (level != null) level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, photos);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        photos.clear();
        ContainerHelper.loadAllItems(tag, photos);
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        saveAdditional(tag);
        return tag;
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
