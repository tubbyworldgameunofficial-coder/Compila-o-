package investigacao.items;

import java.util.function.BiConsumer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;

/** Faixa de isolamento (color = -1) ou carretel de linha colorida (color = RGB). */
public class TapeItem extends Item {
    /** Ligados pelo cliente (este arquivo não referencia classes de cliente). */
    public static BiConsumer<UseOnContext, TapeItem> onUseBlock = (c, i) -> {};
    public static Runnable onCancel = () -> {};

    private final int color;

    public TapeItem(Properties props, int color) {
        super(props);
        this.color = color;
    }

    public int color() { return color; }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        if (ctx.getLevel().isClientSide) onUseBlock.accept(ctx, this);
        return InteractionResult.SUCCESS;
    }

    /** Agachar + clicar no ar cancela a fita em andamento. */
    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide && player.isShiftKeyDown()) {
            onCancel.run();
            return InteractionResultHolder.success(stack);
        }
        return InteractionResultHolder.pass(stack);
    }
}
