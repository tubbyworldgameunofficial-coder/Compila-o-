package investigacao;

import com.mojang.logging.LogUtils;
import investigacao.networking.ModNetwork;
import investigacao.registry.ModBlocks;
import investigacao.registry.ModItems;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/** Ponto único de inicialização do mod Investigação. */
@Mod(Investigacao.MOD_ID)
public class Investigacao {
    public static final String MOD_ID = "investigacao";
    public static final Logger LOG = LogUtils.getLogger();

    public Investigacao() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModBlocks.BLOCK_ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        bus.addListener(this::commonSetup);
        bus.addListener(this::buildTabs);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(ModNetwork::register);
    }

    private void buildTabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            e.accept(ModItems.TAPE);
            ModItems.SPOOLS.values().forEach(e::accept);
            e.accept(ModItems.BOARD_ITEM);
            e.accept(ModItems.LUPA);
            e.accept(ModItems.CLUE_LINE);
        }
    }
}
