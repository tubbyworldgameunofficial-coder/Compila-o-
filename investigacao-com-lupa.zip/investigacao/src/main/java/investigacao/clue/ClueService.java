package investigacao.clue;

import investigacao.clue.ClueData.Link;
import investigacao.clue.ClueData.Pin;
import investigacao.items.ClueLineItem;
import investigacao.networking.ModNetwork;
import investigacao.networking.SyncCluesMessage;
import java.util.List;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

/** Lógica de servidor da Linha Vermelha. */
public final class ClueService {
    public static final double MAX_LEN = 40.0;

    private ClueService() {}

    private static String dim(ServerLevel w) { return w.dimension().location().toString(); }

    private static boolean holds(Player p) {
        for (ItemStack s : new ItemStack[]{p.getMainHandItem(), p.getOffhandItem()}) if (s.getItem() instanceof ClueLineItem) return true;
        return false;
    }

    public static void place(ServerPlayer p, Vec3 pos, Vec3 normal, Vec3 prev) {
        if (!holds(p) || p.getEyePosition().distanceTo(pos) > 12.0) return;
        ServerLevel w = p.serverLevel();
        String d = dim(w);
        boolean chained = prev != null && ClueStore.hasPin(d, prev) && prev.distanceTo(pos) >= 0.05 && prev.distanceTo(pos) <= MAX_LEN;
        ClueStore.pins(d).add(new Pin(pos, normal, !chained));
        if (chained) ClueStore.links(d).add(new Link(prev, pos));
        broadcast(w);
    }

    /** pin = true: remove o pino em a (e as linhas ligadas); senão remove a linha a-b. */
    public static void remove(ServerPlayer p, Vec3 a, Vec3 b, boolean pin) {
        Vec3 e = p.getEyePosition(), ab = b.subtract(a);
        double l2 = ab.lengthSqr();
        double t = pin || l2 < 1.0E-9 ? 0 : Math.max(0, Math.min(1, e.subtract(a).dot(ab) / l2));
        if (e.distanceTo(a.add(ab.scale(t))) > 6.5) return;
        ServerLevel w = p.serverLevel();
        String d = dim(w);
        if (pin) ClueStore.removePin(d, a); else if (!ClueStore.removeLink(d, a, b)) return;
        w.playSound(null, p.blockPosition(), SoundEvents.WOOL_BREAK, SoundSource.PLAYERS, 0.8f, 1.4f);
        broadcast(w);
    }

    public static void sync(ServerPlayer p) {
        String d = dim(p.serverLevel());
        ModNetwork.sendTo(p, new SyncCluesMessage(List.copyOf(ClueStore.pins(d)), List.copyOf(ClueStore.links(d))));
    }

    public static void broadcast(ServerLevel w) { for (ServerPlayer p : w.players()) sync(p); }
}
